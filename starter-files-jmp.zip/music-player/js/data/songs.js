export const songsList = [{
    "id": "1",
    "url": "../../music/nice-for-what.mp3",
    "time": "04:22",
    "title": "Nice For What",
    "artist": "Drake"
  },
  {
    "id": "2",
    "url": "../../music/gods-plan.mp3",
    "time": "03:19",
    "title": "God's Plan",
    "artist": "Drake"
  },
  {
    "id": "3",
    "url": "../../music/professional-rapper.mp3",
    "time": "05:52",
    "title": "Professional Rapper ft. Snoop Dog",
    "artist": "Lil Dicky"
  },
  {
    "id": "4",
    "url": "../../music/yellow.mp3",
    "time": "04:29",
    "title": "Yellow",
    "artist": "Coldplay"
  },
  {
    "id": "5",
    "url": "../../music/get-lucky.mp3",
    "time": "06:09",
    "title": "Get Lucky",
    "artist": "Daft Punk"
  },
  {
    "id": "6",
    "url": "../../music/shape-of-my-heart.mp3",
    "time": "04:43",
    "title": "Shape Of My Heart",
    "artist": "Sting"
  },
  {
    "id": "7",
    "url": "../../music/seven-days.mp3",
    "time": "03:57",
    "title": "7 days",
    "artist": "craig David"
  },
  {
    "id": "8",
    "url": "../../music/dilemma.mp3",
    "time": "04:42",
    "title": "Nelly Dilemma ft. keylly Rowland",
    "artist": "Nelly"
  },
  {
    "id": "9",
    "url": "../../music/psycho.mp3",
    "time": "03:57",
    "title": "Post Malone Psycho Ft. Ty Dolla",
    "artist": "Post malone"
  },
  {
    "id": "10",
    "url": "../../music/congratulations.mp3",
    "time": "03:40",
    "title": "Congratulations ft. Quavo",
    "artist": "Post Malone"
  },
  {
    "id": "11",
    "url": "../../music/rockstar.mp3",
    "time": "04:01",
    "title": "Rockstar",
    "artist": "Post Malone"
  },
  {
    "id": "12",
    "url": "../../music/sad.mp3",
    "time": "02:46",
    "title": "Sad",
    "artist": "XXXtentacion"
  },
];